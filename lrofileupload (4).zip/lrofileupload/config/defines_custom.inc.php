<?php
// config/defines_custom.inc.php
if (!defined('LROFU_STORAGE_ROOT')) {
    define('LROFU_STORAGE_ROOT', '/home/mfjprqzu/lro_uploads'); // OUTSIDE webroot
}

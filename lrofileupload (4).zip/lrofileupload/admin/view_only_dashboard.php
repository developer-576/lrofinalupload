<?php
require_once __DIR__ . '/session_bootstrap.php';

// View-only dashboard logic
?>
<?php
$password = "admin"; // CHANGE THIS
echo password_hash($password, PASSWORD_DEFAULT);

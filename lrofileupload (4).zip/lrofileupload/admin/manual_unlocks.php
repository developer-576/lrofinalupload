<?php
// modules/lrofileupload/admin/manual_unlocks.php
declare(strict_types=1);
/* Backward-compat: some menus point to manual_unlocks.php */
require_once __DIR__.'/manual_unlock.php';

<?php
require_once __DIR__ . '/session_bootstrap.php';

// Shared functions
?>